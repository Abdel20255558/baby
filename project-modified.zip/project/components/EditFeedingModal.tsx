import React, { useEffect, useState } from 'react';
import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Feeding, FeedingType } from '@/types/feeding';

/**
 * A modal dialog allowing the user to edit an existing feeding. Only the
 * type and quantity fields are editable. Duration and times are not
 * modified here. When switching to bottle type, a quantity can be
 * provided. When switching away from bottle, the previous quantity is
 * cleared. The caller is responsible for recalculating any derived
 * fields (durationMinutes) before saving.
 */
interface EditFeedingModalProps {
  visible: boolean;
  feeding: Feeding | null;
  onCancel: () => void;
  onSave: (updatedFeeding: Feeding) => void;
}

export function EditFeedingModal({ visible, feeding, onCancel, onSave }: EditFeedingModalProps) {
  const [type, setType] = useState<FeedingType>('left');
  const [quantity, setQuantity] = useState<string>('');

  useEffect(() => {
    if (feeding) {
      setType(feeding.type);
      setQuantity(
        feeding.type === 'bottle' && feeding.quantityMl !== undefined
          ? feeding.quantityMl.toString()
          : ''
      );
    }
  }, [feeding]);

  if (!feeding) {
    return null;
  }

  const handleSave = () => {
    let quantityNum: number | undefined = undefined;
    if (type === 'bottle') {
      const value = parseInt(quantity, 10);
      if (!isNaN(value) && value > 0) {
        quantityNum = value;
      }
    }
    const updated: Feeding = {
      ...feeding,
      type,
      quantityMl: quantityNum,
    };
    onSave(updated);
  };

  const isBottle = type === 'bottle';

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onCancel}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.overlay}
      >
        <View style={styles.modalContainer}>
          <Text style={styles.title}>Edit Feeding</Text>

          <Text style={styles.subtitle}>Select feeding type</Text>
          <View style={styles.typeContainer}>
            {(['left', 'right', 'bottle'] as FeedingType[]).map((option) => (
              <TouchableOpacity
                key={option}
                style={[
                  styles.typeButton,
                  type === option && styles.typeButtonActive,
                ]}
                onPress={() => setType(option)}
              >
                <Text
                  style={[
                    styles.typeButtonText,
                    type === option && styles.typeButtonTextActive,
                  ]}
                >
                  {option === 'left'
                    ? 'Left'
                    : option === 'right'
                    ? 'Right'
                    : 'Bottle'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {isBottle && (
            <View style={styles.quantitySection}>
              <Text style={styles.subtitle}>Quantity (ml)</Text>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder="120"
                  keyboardType="numeric"
                  value={quantity}
                  onChangeText={setQuantity}
                />
                <Text style={styles.unit}>ml</Text>
              </View>
            </View>
          )}

          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={[styles.button, styles.cancelButton]}
              onPress={onCancel}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, styles.saveButton]}
              onPress={handleSave}
            >
              <Text style={styles.saveButtonText}>Save</Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  modalContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 420,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#2D3748',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#718096',
    marginBottom: 12,
  },
  typeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  typeButton: {
    flex: 1,
    paddingVertical: 12,
    marginHorizontal: 4,
    borderRadius: 12,
    backgroundColor: '#E2E8F0',
    alignItems: 'center',
  },
  typeButtonActive: {
    backgroundColor: '#A0D8B3',
  },
  typeButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4A5568',
    textTransform: 'capitalize',
  },
  typeButtonTextActive: {
    color: '#22543D',
  },
  quantitySection: {
    marginBottom: 24,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },
  input: {
    fontSize: 36,
    fontWeight: '600',
    color: '#2D3748',
    borderBottomWidth: 3,
    borderBottomColor: '#A0D8B3',
    minWidth: 80,
    textAlign: 'center',
    paddingVertical: 8,
  },
  unit: {
    fontSize: 24,
    fontWeight: '600',
    color: '#718096',
    marginLeft: 8,
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  button: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#E2E8F0',
  },
  cancelButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#4A5568',
  },
  saveButton: {
    backgroundColor: '#A0D8B3',
  },
  saveButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2D3748',
  },
});